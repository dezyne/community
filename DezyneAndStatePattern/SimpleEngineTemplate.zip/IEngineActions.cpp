#include "IEngineActions.h"

IEngineActions::IEngineActions()
{
}

IEngineActions::~IEngineActions()
{
}

bool IEngineActions::StartEngine()
{
	return false;
}

void IEngineActions::TurnOffEngine()
{
}
