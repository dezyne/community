#include <string>
#pragma once
class IExceptionHandler
{
public:
	IExceptionHandler();
	virtual ~IExceptionHandler();

	virtual void RaiseException(std::string msg);
};