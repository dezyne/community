#include <iostream>
#include "Engine.h"
#include "EngineState.h"
#include "EngineActions.h"
#include "ExceptionHandler.h"

Engine::Engine(const int intEngineID) :
	m_intEngineID(intEngineID),
	m_engineActions(new EngineActions()),
	m_exceptionHandler(new ExceptionHandler()),
	m_state(new OffState(*this,*m_engineActions,*m_exceptionHandler))
{
}


Engine::~Engine()
{
}

bool Engine::start()
{
	std::cout << m_intEngineID << " Engine -> " << "\n";
	bool res = m_state->start();
	return res;
}

void Engine::stop()
{
	std::cout << m_intEngineID << " Engine -> " << "\n";
	m_state->stop();
}

void Engine::SetState(std::shared_ptr<IEngineState> state)
{
	m_state = state;
}

