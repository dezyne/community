#pragma once
#include "ISetState.h"
#include "IEngineActions.h"
#include "IExceptionHandler.h"

class IEngineState
{
public:
	IEngineState();
	virtual ~IEngineState();
	virtual bool start() = 0;
	virtual void stop() = 0;
};

class OffState : public IEngineState
{
public:
	// during construction we need to pass the initial state
	OffState(
		ISetState& SetState,
		IEngineActions& EngineActions,
		IExceptionHandler& ExceptionHandler);

	virtual  ~OffState();

	virtual bool start();
	virtual void stop();

private:

	ISetState& m_ISetState;
	IEngineActions& m_IEngineActions;
	IExceptionHandler& m_IExceptionHandler;
};

class OnState : public IEngineState
{
public:
	OnState(ISetState& SetState,
		IEngineActions& EngineActions,
		IExceptionHandler& ExceptionHandler);

	virtual ~OnState();

	virtual bool start();
	virtual void stop();

private:
	ISetState& m_ISetState;
	IEngineActions& m_IEngineActions;
	IExceptionHandler& m_IExceptionHandler;
};