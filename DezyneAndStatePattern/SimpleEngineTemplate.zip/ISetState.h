#include <memory>
//
// example State pattern main
//
// authors: Ewald de Bruijn, Julien Schmaltz
// (c) ICT 2019

#ifndef _ISETSTATE_INCLUDED
#define _ISETSTATE_INCLUDED

class IEngineState;

// interface to use by concrete states to change the state of the context object.
class ISetState
{
public:
	// used to Set State
	virtual void SetState(std::shared_ptr<IEngineState> state) = 0;
};

#endif