#pragma once
#include "ISetState.h"
#include "IEngineActions.h"
#include "IExceptionHandler.h"

class Engine :
	public ISetState
{
public:
	explicit Engine(const int intEngineID);
	virtual ~Engine();

	bool start();
	void stop();

	void SetState(std::shared_ptr<IEngineState> state);

private:
	const int                          m_intEngineID;
	std::shared_ptr<IEngineActions>    m_engineActions;
	std::shared_ptr<IExceptionHandler> m_exceptionHandler;
	std::shared_ptr<IEngineState>      m_state;
};

