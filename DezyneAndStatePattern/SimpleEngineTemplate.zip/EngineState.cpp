#include "EngineState.h"

IEngineState::IEngineState()
{
}

IEngineState::~IEngineState()
{
}

OffState::OffState(ISetState& SetState, IEngineActions& EngineActions, IExceptionHandler& ExceptionHandler) :
	m_ISetState(SetState),
 	m_IEngineActions(EngineActions),
	m_IExceptionHandler(ExceptionHandler)
{}

OffState::~OffState()
{}

bool OffState::start()
{
	bool res = false;
	res = m_IEngineActions.StartEngine();
	if (res) {
		std::shared_ptr<IEngineState> newState(new OnState(m_ISetState, m_IEngineActions,m_IExceptionHandler));
		m_ISetState.SetState(newState);
	}
	else {
		m_IExceptionHandler.RaiseException("Start failed !");
	}
	return res;
}

void OffState::stop()
{
	m_IExceptionHandler.RaiseException("Illegal stop, start engine first !");
}


// STATE ON

OnState::OnState(ISetState& SetState, IEngineActions& EngineActions, IExceptionHandler& ExceptionHandler) :
	m_ISetState(SetState),
	m_IEngineActions(EngineActions),
	m_IExceptionHandler(ExceptionHandler)
{}

OnState::~OnState()
{}

bool OnState::start()
{
	m_IExceptionHandler.RaiseException("Illegal start, engine already started !");
	return false;
}

void OnState::stop()
{
	m_IEngineActions.TurnOffEngine();
	std::shared_ptr<IEngineState> newState(new OffState(m_ISetState, m_IEngineActions, m_IExceptionHandler));
	m_ISetState.SetState(newState);
}