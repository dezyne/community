#include "EngineActions.h"
#include <iostream>



EngineActions::EngineActions()
{
}


EngineActions::~EngineActions()
{
}

bool EngineActions::StartEngine()
{
	bool res = false;
	if (ready) {
		std::cout << "Engine started" << "\n";
		ready = false;
		res = true;
	}
	else {
		ready = true;
		res = false;
	}
	return res;
}

void EngineActions::TurnOffEngine()
{
	std::cout << "Engine stopped" << "\n";
}
