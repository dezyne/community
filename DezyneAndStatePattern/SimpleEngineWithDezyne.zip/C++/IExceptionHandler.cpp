#include "IExceptionHandler.h"

IExceptionHandler::IExceptionHandler()
{
}

IExceptionHandler::~IExceptionHandler()
{
}

void IExceptionHandler::RaiseException(std::string msg)
{
}
