#include <iostream>
#include "Engine.h"
#include "EngineActions.h"
#include "ExceptionHandler.h"

Engine::Engine(const int intEngineID) :
	m_intEngineID(intEngineID),
	m_engineActions(new EngineActions()),
	m_exceptionHandler(new ExceptionHandler()),
	m_DnzEngineSystem(loc.set(rt).set(*m_engineActions).set(*m_exceptionHandler))
{
}


Engine::~Engine()
{
}

bool Engine::start()
{
	std::cout << m_intEngineID << " Engine -> " << "\n";
	auto dznRes = m_DnzEngineSystem.pSimpleEngineRobust.in.start();
	return (dznRes == ::callResult_t::Succeeded);
}

void Engine::stop()
{
	std::cout << m_intEngineID << " Engine -> " << "\n";
	m_DnzEngineSystem.pSimpleEngineRobust.in.stop();
}
