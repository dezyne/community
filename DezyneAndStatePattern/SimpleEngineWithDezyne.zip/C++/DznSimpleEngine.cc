// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
#include "DznSimpleEngine.hh"

#include <dzn/locator.hh>
#include <dzn/runtime.hh>



DznSimpleEngineArmour::DznSimpleEngineArmour(const dzn::locator& dzn_locator)
: dzn_meta{"","DznSimpleEngineArmour",0,0,{& rSimpleEngine.meta,& iExceptionHandler.meta},{},{[this]{pSimpleEngineRobust.check_bindings();},[this]{rSimpleEngine.check_bindings();},[this]{iExceptionHandler.check_bindings();}}}
, dzn_rt(dzn_locator.get<dzn::runtime>())
, dzn_locator(dzn_locator)
, state(::state_t::OFF)
, iExceptionHandler(dzn_locator.get< IDznExceptionHandler>())

, pSimpleEngineRobust({{"pSimpleEngineRobust",this,&dzn_meta},{"",0,0}})

, rSimpleEngine({{"",0,0},{"rSimpleEngine",this,&dzn_meta}})


{
  dzn_rt.performs_flush(this) = true;



  pSimpleEngineRobust.in.start = [&](){return dzn::call_in(this,[=]{ return pSimpleEngineRobust_start();}, this->pSimpleEngineRobust.meta, "start");};
  pSimpleEngineRobust.in.stop = [&](){return dzn::call_in(this,[=]{ return pSimpleEngineRobust_stop();}, this->pSimpleEngineRobust.meta, "stop");};



}

::callResult_t::type DznSimpleEngineArmour::pSimpleEngineRobust_start()
{
  if ((state == ::state_t::OFF && true)) 
  {
    bool res = this->rSimpleEngine.in.start();
    {
      if (res) 
      {
        state = ::state_t::ON;
        { this->reply_callResult_t = ::callResult_t::Succeeded; }
      }
      else 
      {
        this->iExceptionHandler.in.RaiseException("Start failed !");
        { this->reply_callResult_t = ::callResult_t::Failed; }
      }
    }
  }
  else if ((state == ::state_t::ON && true)) 
  {
    this->iExceptionHandler.in.RaiseException("Illegal start, engine already started !");
    { this->reply_callResult_t = ::callResult_t::Illegal; }
  }
  else if ((!((state == ::state_t::ON && true)) && (!((state == ::state_t::OFF && true)) && true))) dzn_locator.get<dzn::illegal_handler>().illegal();
  else dzn_locator.get<dzn::illegal_handler>().illegal();

  return this->reply_callResult_t;
}
::callResult_t::type DznSimpleEngineArmour::pSimpleEngineRobust_stop()
{
  if ((state == ::state_t::OFF && true)) 
  {
    this->iExceptionHandler.in.RaiseException("Illegal stop, start engine first !");
    { this->reply_callResult_t = ::callResult_t::Illegal; }
  }
  else if ((state == ::state_t::ON && true)) 
  {
    this->rSimpleEngine.in.stop();
    state = ::state_t::OFF;
    { this->reply_callResult_t = ::callResult_t::Succeeded; }
  }
  else if ((!((state == ::state_t::ON && true)) && (!((state == ::state_t::OFF && true)) && true))) dzn_locator.get<dzn::illegal_handler>().illegal();
  else dzn_locator.get<dzn::illegal_handler>().illegal();

  return this->reply_callResult_t;
}


void DznSimpleEngineArmour::check_bindings() const
{
  dzn::check_bindings(&dzn_meta);
}
void DznSimpleEngineArmour::dump_tree(std::ostream& os) const
{
  dzn::dump_tree(os, &dzn_meta);
}


DznEngineFSM::DznEngineFSM(const dzn::locator& dzn_locator)
: dzn_meta{"","DznEngineFSM",0,0,{& rEngineActions.meta},{},{[this]{pSimpleEngine.check_bindings();},[this]{rEngineActions.check_bindings();}}}
, dzn_rt(dzn_locator.get<dzn::runtime>())
, dzn_locator(dzn_locator)
, state(::state_t::OFF)

, pSimpleEngine({{"pSimpleEngine",this,&dzn_meta},{"",0,0}})

, rEngineActions({{"",0,0},{"rEngineActions",this,&dzn_meta}})


{
  dzn_rt.performs_flush(this) = true;

  pSimpleEngine.in.stop = [&](){return dzn::call_in(this,[=]{ return pSimpleEngine_stop();}, this->pSimpleEngine.meta, "stop");};


  pSimpleEngine.in.start = [&](){return dzn::call_in(this,[=]{ return pSimpleEngine_start();}, this->pSimpleEngine.meta, "start");};



}

bool DznEngineFSM::pSimpleEngine_start()
{
  if ((state == ::state_t::OFF && true)) 
  {
    bool res = this->rEngineActions.in.StartEngine();
    {
      if (res) state = ::state_t::ON;
    }
    { this->reply_bool = res; }
  }
  else if ((!((state == ::state_t::OFF && true)) && true)) dzn_locator.get<dzn::illegal_handler>().illegal();
  else dzn_locator.get<dzn::illegal_handler>().illegal();

  return this->reply_bool;
}
void DznEngineFSM::pSimpleEngine_stop()
{
  if ((state == ::state_t::ON && true)) 
  {
    this->rEngineActions.in.TurnOffEngine();
    state = ::state_t::OFF;
  }
  else if ((!((state == ::state_t::ON && true)) && true)) dzn_locator.get<dzn::illegal_handler>().illegal();
  else dzn_locator.get<dzn::illegal_handler>().illegal();

  return;

}


void DznEngineFSM::check_bindings() const
{
  dzn::check_bindings(&dzn_meta);
}
void DznEngineFSM::dump_tree(std::ostream& os) const
{
  dzn::dump_tree(os, &dzn_meta);
}

//SYSTEM

DznSimpleEngineSystem::DznSimpleEngineSystem(const dzn::locator& dzn_locator)
: dzn_meta{"","DznSimpleEngineSystem",0,0,{},{& engineArmour.dzn_meta,& engineFSM.dzn_meta,& exceptionHandler.dzn_meta,& engineActions.dzn_meta},{[this]{pSimpleEngineRobust.check_bindings();}}}
, dzn_rt(dzn_locator.get<dzn::runtime>())
, dzn_locator(dzn_locator)
, exceptionHandler(dzn_locator)

, dzn_local_locator(dzn_locator.clone().set(exceptionHandler.pExceptionHandler))
, engineArmour(dzn_local_locator)
, engineFSM(dzn_local_locator)
, engineActions(dzn_local_locator)

, pSimpleEngineRobust(engineArmour.pSimpleEngineRobust)

{

  exceptionHandler.dzn_meta.parent = &dzn_meta;
  exceptionHandler.dzn_meta.name = "exceptionHandler";
  exceptionHandler.pExceptionHandler.meta.requires.port = "pExceptionHandler";

  engineArmour.dzn_meta.parent = &dzn_meta;
  engineArmour.dzn_meta.name = "engineArmour";
  engineFSM.dzn_meta.parent = &dzn_meta;
  engineFSM.dzn_meta.name = "engineFSM";
  engineActions.dzn_meta.parent = &dzn_meta;
  engineActions.dzn_meta.name = "engineActions";


  connect(engineFSM.pSimpleEngine, engineArmour.rSimpleEngine);
  connect(engineActions.pEngineActions, engineFSM.rEngineActions);

  dzn::rank(pSimpleEngineRobust.meta.provides.meta, 0);

}

void DznSimpleEngineSystem::check_bindings() const
{
  dzn::check_bindings(&dzn_meta);
}
void DznSimpleEngineSystem::dump_tree(std::ostream& os) const
{
  dzn::dump_tree(os, &dzn_meta);
}

////////////////////////////////////////////////////////////////////////////////



//version: 2.8.2