#pragma once
class IEngineActions
{
public:
	IEngineActions();
	virtual ~IEngineActions();

	virtual bool StartEngine();
	virtual void TurnOffEngine();
};


