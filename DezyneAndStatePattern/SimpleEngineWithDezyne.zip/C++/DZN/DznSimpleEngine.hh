// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
#include <dzn/meta.hh>

namespace dzn {
  struct locator;
  struct runtime;
}



#include <iostream>
#include <map>

/********************************** INTERFACE *********************************/
#ifndef IDZNSIMPLEENGINE_HH
#define IDZNSIMPLEENGINE_HH



#ifndef ENUM_state_t
#define ENUM_state_t 1


struct state_t
{
  enum type
  {
    OFF,ON
  };
};


#endif // ENUM_state_t
#ifndef ENUM_callResult_t
#define ENUM_callResult_t 1


struct callResult_t
{
  enum type
  {
    Succeeded,Failed,Illegal
  };
};


#endif // ENUM_callResult_t

struct IDznSimpleEngine
{

  struct
  {
    std::function< bool()> start;
    std::function< void()> stop;
  } in;

  struct
  {
  } out;

  dzn::port::meta meta;
  inline IDznSimpleEngine(const dzn::port::meta& m) : meta(m) {}

  void check_bindings() const
  {
    if (! in.start) throw dzn::binding_error(meta, "in.start");
    if (! in.stop) throw dzn::binding_error(meta, "in.stop");


  }
};

inline void connect (IDznSimpleEngine& provided, IDznSimpleEngine& required)
{
  provided.out = required.out;
  required.in = provided.in;
  provided.meta.requires = required.meta.requires;
  required.meta.provides = provided.meta.provides;
}


#ifndef ENUM_TO_STRING_state_t
#define ENUM_TO_STRING_state_t 1
inline std::string to_string(::state_t::type v)
{
  switch(v)
  {
    case ::state_t::OFF: return "state_t_OFF";
    case ::state_t::ON: return "state_t_ON";

  }
  return "";
}
#endif // ENUM_TO_STRING_state_t
#ifndef ENUM_TO_STRING_callResult_t
#define ENUM_TO_STRING_callResult_t 1
inline std::string to_string(::callResult_t::type v)
{
  switch(v)
  {
    case ::callResult_t::Succeeded: return "callResult_t_Succeeded";
    case ::callResult_t::Failed: return "callResult_t_Failed";
    case ::callResult_t::Illegal: return "callResult_t_Illegal";

  }
  return "";
}
#endif // ENUM_TO_STRING_callResult_t

#ifndef STRING_TO_ENUM_state_t
#define STRING_TO_ENUM_state_t 1
inline ::state_t::type to_state_t(std::string s)
{
  static std::map<std::string, ::state_t::type> m = {
    {"state_t_OFF", ::state_t::OFF},
    {"state_t_ON", ::state_t::ON},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_state_t
#ifndef STRING_TO_ENUM_callResult_t
#define STRING_TO_ENUM_callResult_t 1
inline ::callResult_t::type to_callResult_t(std::string s)
{
  static std::map<std::string, ::callResult_t::type> m = {
    {"callResult_t_Succeeded", ::callResult_t::Succeeded},
    {"callResult_t_Failed", ::callResult_t::Failed},
    {"callResult_t_Illegal", ::callResult_t::Illegal},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_callResult_t


#endif // IDZNSIMPLEENGINE_HH

/********************************** INTERFACE *********************************/
/********************************** INTERFACE *********************************/
#ifndef IDZNSIMPLEENGINEROBUST_HH
#define IDZNSIMPLEENGINEROBUST_HH



#ifndef ENUM_state_t
#define ENUM_state_t 1


struct state_t
{
  enum type
  {
    OFF,ON
  };
};


#endif // ENUM_state_t
#ifndef ENUM_callResult_t
#define ENUM_callResult_t 1


struct callResult_t
{
  enum type
  {
    Succeeded,Failed,Illegal
  };
};


#endif // ENUM_callResult_t

struct IDznSimpleEngineRobust
{

  struct
  {
    std::function< ::callResult_t::type()> start;
    std::function< ::callResult_t::type()> stop;
  } in;

  struct
  {
  } out;

  dzn::port::meta meta;
  inline IDznSimpleEngineRobust(const dzn::port::meta& m) : meta(m) {}

  void check_bindings() const
  {
    if (! in.start) throw dzn::binding_error(meta, "in.start");
    if (! in.stop) throw dzn::binding_error(meta, "in.stop");


  }
};

inline void connect (IDznSimpleEngineRobust& provided, IDznSimpleEngineRobust& required)
{
  provided.out = required.out;
  required.in = provided.in;
  provided.meta.requires = required.meta.requires;
  required.meta.provides = provided.meta.provides;
}


#ifndef ENUM_TO_STRING_state_t
#define ENUM_TO_STRING_state_t 1
inline std::string to_string(::state_t::type v)
{
  switch(v)
  {
    case ::state_t::OFF: return "state_t_OFF";
    case ::state_t::ON: return "state_t_ON";

  }
  return "";
}
#endif // ENUM_TO_STRING_state_t
#ifndef ENUM_TO_STRING_callResult_t
#define ENUM_TO_STRING_callResult_t 1
inline std::string to_string(::callResult_t::type v)
{
  switch(v)
  {
    case ::callResult_t::Succeeded: return "callResult_t_Succeeded";
    case ::callResult_t::Failed: return "callResult_t_Failed";
    case ::callResult_t::Illegal: return "callResult_t_Illegal";

  }
  return "";
}
#endif // ENUM_TO_STRING_callResult_t

#ifndef STRING_TO_ENUM_state_t
#define STRING_TO_ENUM_state_t 1
inline ::state_t::type to_state_t(std::string s)
{
  static std::map<std::string, ::state_t::type> m = {
    {"state_t_OFF", ::state_t::OFF},
    {"state_t_ON", ::state_t::ON},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_state_t
#ifndef STRING_TO_ENUM_callResult_t
#define STRING_TO_ENUM_callResult_t 1
inline ::callResult_t::type to_callResult_t(std::string s)
{
  static std::map<std::string, ::callResult_t::type> m = {
    {"callResult_t_Succeeded", ::callResult_t::Succeeded},
    {"callResult_t_Failed", ::callResult_t::Failed},
    {"callResult_t_Illegal", ::callResult_t::Illegal},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_callResult_t


#endif // IDZNSIMPLEENGINEROBUST_HH

/********************************** INTERFACE *********************************/
/********************************** INTERFACE *********************************/
#ifndef IDZNEXCEPTIONHANDLER_HH
#define IDZNEXCEPTIONHANDLER_HH



#ifndef ENUM_state_t
#define ENUM_state_t 1


struct state_t
{
  enum type
  {
    OFF,ON
  };
};


#endif // ENUM_state_t
#ifndef ENUM_callResult_t
#define ENUM_callResult_t 1


struct callResult_t
{
  enum type
  {
    Succeeded,Failed,Illegal
  };
};


#endif // ENUM_callResult_t

struct IDznExceptionHandler
{

  struct
  {
    std::function< void(std::string txt)> RaiseException;
  } in;

  struct
  {
  } out;

  dzn::port::meta meta;
  inline IDznExceptionHandler(const dzn::port::meta& m) : meta(m) {}

  void check_bindings() const
  {
    if (! in.RaiseException) throw dzn::binding_error(meta, "in.RaiseException");


  }
};

inline void connect (IDznExceptionHandler& provided, IDznExceptionHandler& required)
{
  provided.out = required.out;
  required.in = provided.in;
  provided.meta.requires = required.meta.requires;
  required.meta.provides = provided.meta.provides;
}


#ifndef ENUM_TO_STRING_state_t
#define ENUM_TO_STRING_state_t 1
inline std::string to_string(::state_t::type v)
{
  switch(v)
  {
    case ::state_t::OFF: return "state_t_OFF";
    case ::state_t::ON: return "state_t_ON";

  }
  return "";
}
#endif // ENUM_TO_STRING_state_t
#ifndef ENUM_TO_STRING_callResult_t
#define ENUM_TO_STRING_callResult_t 1
inline std::string to_string(::callResult_t::type v)
{
  switch(v)
  {
    case ::callResult_t::Succeeded: return "callResult_t_Succeeded";
    case ::callResult_t::Failed: return "callResult_t_Failed";
    case ::callResult_t::Illegal: return "callResult_t_Illegal";

  }
  return "";
}
#endif // ENUM_TO_STRING_callResult_t

#ifndef STRING_TO_ENUM_state_t
#define STRING_TO_ENUM_state_t 1
inline ::state_t::type to_state_t(std::string s)
{
  static std::map<std::string, ::state_t::type> m = {
    {"state_t_OFF", ::state_t::OFF},
    {"state_t_ON", ::state_t::ON},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_state_t
#ifndef STRING_TO_ENUM_callResult_t
#define STRING_TO_ENUM_callResult_t 1
inline ::callResult_t::type to_callResult_t(std::string s)
{
  static std::map<std::string, ::callResult_t::type> m = {
    {"callResult_t_Succeeded", ::callResult_t::Succeeded},
    {"callResult_t_Failed", ::callResult_t::Failed},
    {"callResult_t_Illegal", ::callResult_t::Illegal},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_callResult_t


#endif // IDZNEXCEPTIONHANDLER_HH

/********************************** INTERFACE *********************************/
/********************************** INTERFACE *********************************/
#ifndef IDZNENGINEACTIONS_HH
#define IDZNENGINEACTIONS_HH



#ifndef ENUM_state_t
#define ENUM_state_t 1


struct state_t
{
  enum type
  {
    OFF,ON
  };
};


#endif // ENUM_state_t
#ifndef ENUM_callResult_t
#define ENUM_callResult_t 1


struct callResult_t
{
  enum type
  {
    Succeeded,Failed,Illegal
  };
};


#endif // ENUM_callResult_t

struct IDznEngineActions
{

  struct
  {
    std::function< bool()> StartEngine;
    std::function< void()> TurnOffEngine;
  } in;

  struct
  {
  } out;

  dzn::port::meta meta;
  inline IDznEngineActions(const dzn::port::meta& m) : meta(m) {}

  void check_bindings() const
  {
    if (! in.StartEngine) throw dzn::binding_error(meta, "in.StartEngine");
    if (! in.TurnOffEngine) throw dzn::binding_error(meta, "in.TurnOffEngine");


  }
};

inline void connect (IDznEngineActions& provided, IDznEngineActions& required)
{
  provided.out = required.out;
  required.in = provided.in;
  provided.meta.requires = required.meta.requires;
  required.meta.provides = provided.meta.provides;
}


#ifndef ENUM_TO_STRING_state_t
#define ENUM_TO_STRING_state_t 1
inline std::string to_string(::state_t::type v)
{
  switch(v)
  {
    case ::state_t::OFF: return "state_t_OFF";
    case ::state_t::ON: return "state_t_ON";

  }
  return "";
}
#endif // ENUM_TO_STRING_state_t
#ifndef ENUM_TO_STRING_callResult_t
#define ENUM_TO_STRING_callResult_t 1
inline std::string to_string(::callResult_t::type v)
{
  switch(v)
  {
    case ::callResult_t::Succeeded: return "callResult_t_Succeeded";
    case ::callResult_t::Failed: return "callResult_t_Failed";
    case ::callResult_t::Illegal: return "callResult_t_Illegal";

  }
  return "";
}
#endif // ENUM_TO_STRING_callResult_t

#ifndef STRING_TO_ENUM_state_t
#define STRING_TO_ENUM_state_t 1
inline ::state_t::type to_state_t(std::string s)
{
  static std::map<std::string, ::state_t::type> m = {
    {"state_t_OFF", ::state_t::OFF},
    {"state_t_ON", ::state_t::ON},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_state_t
#ifndef STRING_TO_ENUM_callResult_t
#define STRING_TO_ENUM_callResult_t 1
inline ::callResult_t::type to_callResult_t(std::string s)
{
  static std::map<std::string, ::callResult_t::type> m = {
    {"callResult_t_Succeeded", ::callResult_t::Succeeded},
    {"callResult_t_Failed", ::callResult_t::Failed},
    {"callResult_t_Illegal", ::callResult_t::Illegal},
  };
  return m.at(s);
}
#endif // STRING_TO_ENUM_callResult_t


#endif // IDZNENGINEACTIONS_HH

/********************************** INTERFACE *********************************/
/***********************************  FOREIGN  **********************************/
#ifndef SKEL_DZNEXCEPTIONHANDLER_HH
#define SKEL_DZNEXCEPTIONHANDLER_HH

#include <dzn/locator.hh>
#include <dzn/runtime.hh>




namespace skel {
  struct DznExceptionHandler
  {
    dzn::meta dzn_meta;
    dzn::runtime& dzn_rt;
    dzn::locator const& dzn_locator;
    ::IDznExceptionHandler pExceptionHandler;


    DznExceptionHandler(const dzn::locator& dzn_locator)
    : dzn_meta{"","DznExceptionHandler",0,0,{},{},{[this]{pExceptionHandler.check_bindings();}}}
    , dzn_rt(dzn_locator.get<dzn::runtime>())
    , dzn_locator(dzn_locator)

    , pExceptionHandler({{"pExceptionHandler",this,&dzn_meta},{"",0,0}})


    {
      pExceptionHandler.in.RaiseException = [&](std::string txt){return dzn::call_in(this,[=]{ return pExceptionHandler_RaiseException(txt);}, this->pExceptionHandler.meta, "RaiseException");};


    }
    virtual ~ DznExceptionHandler() {}
    virtual std::ostream& stream_members(std::ostream& os) const { return os; }
    void check_bindings() const;
    void dump_tree(std::ostream& os) const;
    void set_state(std::map<std::string,std::map<std::string,std::string> >){}
    void set_state(std::map<std::string,std::string>_alist){}
    friend std::ostream& operator << (std::ostream& os, const DznExceptionHandler& m)  {
      return m.stream_members(os);
    }
    private:
    virtual void pExceptionHandler_RaiseException (std::string txt) = 0;

  };
}

#endif // DZNEXCEPTIONHANDLER_HH

/***********************************  FOREIGN  **********************************/
/********************************** COMPONENT *********************************/
#ifndef DZNSIMPLEENGINEARMOUR_HH
#define DZNSIMPLEENGINEARMOUR_HH




struct DznSimpleEngineArmour
{
  dzn::meta dzn_meta;
  dzn::runtime& dzn_rt;
  dzn::locator const& dzn_locator;

  ::state_t::type state;

  ::callResult_t::type reply_callResult_t;
  bool reply_bool;

  std::function<void ()> out_pSimpleEngineRobust;

  ::IDznSimpleEngineRobust pSimpleEngineRobust;

  ::IDznSimpleEngine rSimpleEngine;
  ::IDznExceptionHandler iExceptionHandler;


  DznSimpleEngineArmour(const dzn::locator&);
  void check_bindings() const;
  void dump_tree(std::ostream& os) const;
  friend std::ostream& operator << (std::ostream& os, const DznSimpleEngineArmour& m)  {
    (void)m;
    return os << "[" << m.state <<"]" ;
  }
  private:
  ::callResult_t::type pSimpleEngineRobust_start();
  ::callResult_t::type pSimpleEngineRobust_stop();

};

#endif // DZNSIMPLEENGINEARMOUR_HH

/********************************** COMPONENT *********************************/
/***********************************  FOREIGN  **********************************/
#ifndef SKEL_DZNENGINEACTIONS_HH
#define SKEL_DZNENGINEACTIONS_HH

#include <dzn/locator.hh>
#include <dzn/runtime.hh>




namespace skel {
  struct DznEngineActions
  {
    dzn::meta dzn_meta;
    dzn::runtime& dzn_rt;
    dzn::locator const& dzn_locator;
    ::IDznEngineActions pEngineActions;


    DznEngineActions(const dzn::locator& dzn_locator)
    : dzn_meta{"","DznEngineActions",0,0,{},{},{[this]{pEngineActions.check_bindings();}}}
    , dzn_rt(dzn_locator.get<dzn::runtime>())
    , dzn_locator(dzn_locator)

    , pEngineActions({{"pEngineActions",this,&dzn_meta},{"",0,0}})


    {
      pEngineActions.in.TurnOffEngine = [&](){return dzn::call_in(this,[=]{ return pEngineActions_TurnOffEngine();}, this->pEngineActions.meta, "TurnOffEngine");};

      pEngineActions.in.StartEngine = [&](){return dzn::call_in(this,[=]{ return pEngineActions_StartEngine();}, this->pEngineActions.meta, "StartEngine");};

    }
    virtual ~ DznEngineActions() {}
    virtual std::ostream& stream_members(std::ostream& os) const { return os; }
    void check_bindings() const;
    void dump_tree(std::ostream& os) const;
    void set_state(std::map<std::string,std::map<std::string,std::string> >){}
    void set_state(std::map<std::string,std::string>_alist){}
    friend std::ostream& operator << (std::ostream& os, const DznEngineActions& m)  {
      return m.stream_members(os);
    }
    private:
    virtual bool pEngineActions_StartEngine () = 0;
    virtual void pEngineActions_TurnOffEngine () = 0;

  };
}

#endif // DZNENGINEACTIONS_HH

/***********************************  FOREIGN  **********************************/
/********************************** COMPONENT *********************************/
#ifndef DZNENGINEFSM_HH
#define DZNENGINEFSM_HH




struct DznEngineFSM
{
  dzn::meta dzn_meta;
  dzn::runtime& dzn_rt;
  dzn::locator const& dzn_locator;

  ::state_t::type state;

  bool reply_bool;

  std::function<void ()> out_pSimpleEngine;

  ::IDznSimpleEngine pSimpleEngine;

  ::IDznEngineActions rEngineActions;


  DznEngineFSM(const dzn::locator&);
  void check_bindings() const;
  void dump_tree(std::ostream& os) const;
  friend std::ostream& operator << (std::ostream& os, const DznEngineFSM& m)  {
    (void)m;
    return os << "[" << m.state <<"]" ;
  }
  private:
  bool pSimpleEngine_start();
  void pSimpleEngine_stop();

};

#endif // DZNENGINEFSM_HH

/********************************** COMPONENT *********************************/
/***********************************  SYSTEM  ***********************************/
#ifndef DZNSIMPLEENGINESYSTEM_HH
#define DZNSIMPLEENGINESYSTEM_HH


#include <dzn/locator.hh>

#include "DznExceptionHandler.hh"
#include "DznEngineActions.hh"



struct DznSimpleEngineSystem
{
  dzn::meta dzn_meta;
  dzn::runtime& dzn_rt;
  dzn::locator const& dzn_locator;
  ::DznExceptionHandler exceptionHandler;

  dzn::locator dzn_local_locator;

  ::DznSimpleEngineArmour engineArmour;
  ::DznEngineFSM engineFSM;
  ::DznEngineActions engineActions;

  ::IDznSimpleEngineRobust& pSimpleEngineRobust;


  DznSimpleEngineSystem(const dzn::locator&);
  void check_bindings() const;
  void dump_tree(std::ostream& os=std::clog) const;
};

#endif // DZNSIMPLEENGINESYSTEM_HH

/***********************************  SYSTEM  ***********************************/


//version: 2.8.2
