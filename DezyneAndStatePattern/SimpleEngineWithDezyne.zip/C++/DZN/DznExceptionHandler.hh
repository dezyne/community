#include "DznSimpleEngine.hh"
#include "ExceptionHandler.h"

class DznExceptionHandler : public skel::DznExceptionHandler
{
public: 

	DznExceptionHandler(const dzn::locator& loc) : 
		m_ExceptionHandler(loc.get<IExceptionHandler>())
		, skel::DznExceptionHandler(loc)
	{

	}

	virtual void pExceptionHandler_RaiseException(std::string msg)
	{
		m_ExceptionHandler.RaiseException(msg);
	}
private:
	IExceptionHandler& m_ExceptionHandler;
};