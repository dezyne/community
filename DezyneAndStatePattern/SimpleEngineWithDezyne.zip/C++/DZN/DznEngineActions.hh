#include "DznSimpleEngine.hh"
#include "EngineActions.h"

class DznEngineActions : public skel::DznEngineActions
{
public:
	DznEngineActions(const dzn::locator& loc) :
		m_engineActions(loc.get<IEngineActions>())
		, skel::DznEngineActions(loc)
	{

	}

	bool pEngineActions_StartEngine()
	{
		return m_engineActions.StartEngine();
	}

	void pEngineActions_TurnOffEngine()
	{
		return m_engineActions.TurnOffEngine();
	}

private:
	IEngineActions& m_engineActions;
};

#pragma once

