#pragma once

#include "IEngineActions.h"
#include "IExceptionHandler.h"
#include "DznSimpleEngine.hh"
#include <dzn/locator.hh>
#include <dzn/runtime.hh>

class Engine
{
public:
	explicit Engine(const int intEngineID);
	virtual ~Engine();

	bool start();
	void stop();

private:
	const int                          m_intEngineID;
	std::shared_ptr<IEngineActions>    m_engineActions;
	std::shared_ptr<IExceptionHandler> m_exceptionHandler;
	// add the dezyne system
	dzn::locator                       loc;
	dzn::runtime                       rt;
	DznSimpleEngineSystem              m_DnzEngineSystem;
};

