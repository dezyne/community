#include <iostream>
#include "IExceptionHandler.h"
#pragma once

class ExceptionHandler : public IExceptionHandler
{
public:
	ExceptionHandler()
	{
	}
	virtual ~ExceptionHandler()
	{
	}

	void RaiseException(std::string msg)
	{
		std::cout << "Error :  " << msg << "\n";
	}
};
