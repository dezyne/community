#pragma once
#include "IEngineActions.h"
class EngineActions :
	public IEngineActions
{
public:
	EngineActions();
	virtual ~EngineActions();

	bool StartEngine();
	void TurnOffEngine();

private:
	bool ready = true;
};

